// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Planta_Ataque.h"
#include "Lanza_Guisantes.generated.h"

/**
 * 
 */
UCLASS()
class PVZ_USFX_LAB02_API ALanza_Guisantes : public APlanta_Ataque
{
	GENERATED_BODY()
	
};
