// Copyright Epic Games, Inc. All Rights Reserved.

#include "PVZ_USFX_LAB02.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, PVZ_USFX_LAB02, "PVZ_USFX_LAB02" );
