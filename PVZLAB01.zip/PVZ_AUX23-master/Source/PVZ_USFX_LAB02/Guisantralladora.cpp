// Fill out your copyright notice in the Description page of Project Settings.


#include "Guisantralladora.h"

AGuisantralladora::AGuisantralladora()
{
	MeshPlanta->SetRelativeScale3D(FVector(1.5f, 1.5f, 2.5f));

}

